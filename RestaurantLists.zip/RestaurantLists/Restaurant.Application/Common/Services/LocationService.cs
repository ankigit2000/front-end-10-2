﻿using Restaurant.Application.Common.Interfaces;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Restaurant.Application.Common.Services
{
    public class LocationService:ILocationService
    {
        private readonly ILocationRepository _locationRepository;

        public LocationService(ILocationRepository _locationRepository)
        {
            this._locationRepository = _locationRepository;
        }

        public async Task<RestaurantLocation> AddAsync(RestaurantLocation location)
        {
            return await _locationRepository.AddAsync(location);
        }

        public async Task<RestaurantLocation> DeleteAsync(int id)
        {
            return await _locationRepository.DeleteAsync(id);
        }

        public async Task<IEnumerable<RestaurantLocation>> GetAllAsync()
        {
            return await _locationRepository.GetAllAsync();
        }

        public async Task<RestaurantLocation> GetAsync(int id)
        {
            return await _locationRepository.GetAsync(id);
        }

        public async Task<RestaurantLocation> UpdateAsync(int id, RestaurantLocation updated)
        {
            return await _locationRepository.UpdateAsync(id, updated);
        }
    }
}
