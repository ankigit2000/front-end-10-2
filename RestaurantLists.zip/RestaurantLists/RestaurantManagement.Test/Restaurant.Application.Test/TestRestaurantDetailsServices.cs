﻿using Moq;
using Restaurant.Application.Common.Services;
using Restaurant.Domain.Entities;
using Restaurant.Domain.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace RestaurantManagement.Test.Restaurant.Application.Test
{
    public class TestRestaurantDetailsServices
    {
        private readonly IRestaurantDetailsRepository _mockRepository;
        private readonly RestaurantDetailsService _service;
        private readonly RestaurantDetails _restaurantDetails;
        public TestRestaurantDetailsServices()
        {
            _mockRepository = Mock.Of<IRestaurantDetailsRepository>();
            _service = new RestaurantDetailsService(_mockRepository);
            _restaurantDetails = new RestaurantDetails { RestaurantID= 1, Restaurant = "Test Restaurant" };
        }

        [Fact]
        public async Task AddAsync_Should_Add_RestaurantDetails()
        {
            // Arrange
            Mock.Get(_mockRepository).Setup(repo => repo.AddAsync(It.IsAny<RestaurantDetails>()))
                .ReturnsAsync(_restaurantDetails);

            // Act
            var result = await _service.AddAsync(_restaurantDetails);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.RestaurantID);
            Assert.Equal("Test Restaurant", result.Restaurant);
        }

        [Fact]
        public async Task DeleteAsync_Should_Delete_RestaurantDetails()
        {
            // Arrange
            Mock.Get(_mockRepository).Setup(repo => repo.DeleteAsync(It.IsAny<int>()))
                .ReturnsAsync(_restaurantDetails);

            // Act
            var result = await _service.DeleteAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.RestaurantID);
            Assert.Equal("Test Restaurant", result.Restaurant);
        }

        [Fact]
        public async Task GetAllAsync_Should_Get_All_RestaurantDetails()
        {
            // Arrange
            var restaurantDetailsList = new List<RestaurantDetails>
            {
                new RestaurantDetails { RestaurantID = 1, Restaurant = "Test Restaurant 1" },
                new RestaurantDetails { RestaurantID = 2, Restaurant = "Test Restaurant 2" }
            };

            Mock.Get(_mockRepository).Setup(repo => repo.GetAllAsync())
                .ReturnsAsync(restaurantDetailsList);

            // Act
            var result = await _service.GetAllAsync();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count());
        }

        [Fact]
        public async Task GetAsync_Should_Get_RestaurantDetails_By_Id()
        {
            // Arrange
            Mock.Get(_mockRepository).Setup(repo => repo.GetAsync(It.IsAny<int>()))
                .ReturnsAsync(_restaurantDetails);

            // Act
            var result = await _service.GetAsync(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.RestaurantID);
            Assert.Equal("Test Restaurant", result.Restaurant);
        }
        [Fact]
        public async Task UpdateAsync_Should_Update_RestaurantDetails()
        {
            // Arrange
            var updatedRestaurantDetails = new RestaurantDetails { RestaurantID = 1, Restaurant = "Updated Restaurant" };
            Mock.Get(_mockRepository).Setup(repo => repo.UpdateAsync(It.IsAny<int>(), It.IsAny<RestaurantDetails>()))
                .ReturnsAsync(updatedRestaurantDetails);

            // Act
            var result = await _service.UpdateAsync(1, updatedRestaurantDetails);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.RestaurantID);
            Assert.Equal("Updated Restaurant", result.Restaurant);
        }
    }
}

