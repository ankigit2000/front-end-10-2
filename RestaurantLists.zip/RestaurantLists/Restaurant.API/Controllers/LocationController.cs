﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Restaurant.Application.Common.Interfaces;

namespace Restaurant.API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LocationController : Controller
    {
        private readonly ILocationService locationService;

        public LocationController(ILocationService locationService)
        {
            this.locationService= locationService;
        }
        [HttpGet]
        public async Task<IActionResult> GetAllLocationsAsync()
        {
            var locations = await locationService.GetAllAsync();
            return Ok(locations);

        }

        [HttpGet]
        [Route("{id}")]
        [ActionName("GetLocationsAsync")]
        public async Task<IActionResult> GetLocationsAsync(int id)
        {
            var location = await locationService.GetAsync(id);

            if (location == null)
            {
                return NotFound();
            }
            return Ok(location);
        }

        [HttpPost]
        public async Task<IActionResult> AddCitiesAsync(Restaurant.Infrastructure.Persistance.DTO.AddRestaurantLocation addRestaurantLocation)
        {
            //Request to Domain Model
            var location = new Restaurant.Domain.Entities.RestaurantLocation()
            {

                Address= addRestaurantLocation.Address,
                CityID= addRestaurantLocation.CityID,
                StateID = addRestaurantLocation.StateID,
                UpdatedBy = addRestaurantLocation.UpdatedBy,
                UpdatedDate = addRestaurantLocation.UpdatedDate

            };
            location = await locationService.AddAsync(location);
            var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation
            {
                LocationID = location.LocationID,
                Address = location.Address,
                CityID = location.CityID,
                StateID = location.StateID,
                UpdatedBy = location.UpdatedBy,
                UpdatedDate = location.UpdatedDate

            };
            return CreatedAtAction(nameof(GetLocationsAsync), new { id = locationDTO.LocationID }, locationDTO);

        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<IActionResult> DeleteLocationsAsync(int id)
        {
            var location = await locationService.DeleteAsync(id);
            if (location == null)
            {
                return NotFound();
            }

            var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation
            {
                LocationID = location.LocationID,
                Address = location.Address,
                CityID = location.CityID,
                StateID = location.StateID,
                UpdatedBy = location.UpdatedBy,
                UpdatedDate = location.UpdatedDate
            };
            return Ok(locationDTO);
        }
        [HttpPut]
        [Route("{id}")]
        public async Task<IActionResult> UpdatedCityAsync([FromRoute] int id, [FromBody] Restaurant.Infrastructure.Persistance.DTO.UpdateRestaurantLocation updateRestaurantLocation)
        {
            var location = new Restaurant.Domain.Entities.RestaurantLocation()
            {
                Address = updateRestaurantLocation.Address,
                CityID = updateRestaurantLocation.CityID,
                StateID = updateRestaurantLocation.StateID,
                UpdatedBy = updateRestaurantLocation.UpdatedBy,
                UpdatedDate = updateRestaurantLocation.UpdatedDate

            };
            location = await locationService.UpdateAsync(id, location);
            if (location == null)
            {
                return NotFound();
            }
            var locationDTO = new Restaurant.Infrastructure.Persistance.DTO.RestaurantLocation()
            {
                LocationID = location.LocationID,
                Address = location.Address,
                CityID = location.CityID,
                StateID = location.StateID,
                UpdatedBy = location.UpdatedBy,
                UpdatedDate = location.UpdatedDate
            };
            return Ok(locationDTO);
        }
    }
}
